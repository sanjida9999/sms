
<h2 align="center">
<a href="https://maocommunity.blogspot.com/?m=1">TBOMB_MAO</a>
  
  </h2>
</br>
<b><i>THIS IS A SMS,CALL AND MAIL BOMBING TOOL,.
IT 100% WORKING NOW,! YOU CAN SEND BULK SMS AND CALL UNLIMITED,!
YOU CAN ALSO SEND MAIL,! WITH THIS TOOL.!</i></b>
</br>
</br>

<p align="center">
<b> AUTHER </b>
</p>
 <p align="center">
<a href="https://github.com/mao2116">
  <img width="50px" height="50px" src="https://raw.githubusercontent.com/fh-rabbi/Hack-Box/main/images/git.png">
</a>
<a href="https://www.facebook.com/mao2116/">
  <img width="50px" height="50px" src="https://raw.githubusercontent.com/fh-rabbi/Hack-Box/main/images/fb.png"><!I JUST USE A PIC FROM FH-RABBI >
</a></p>

  
#### THIS TOOL IS OPEN SOURCE FOR ONLY LEARNING PATH NOT FOR COPY.

##### JUST ENTER YOUR COUNTRY CODE !





### INSTALLATION [ RECOMMENDED ] :

* `apt-get update -y`
* `pkg install curl -y`
* `pkg install python -y`
* `pip install requests`
* `curl https://codeload.github.com/mao2116/tbomb_mao/zip/refs/heads/main --output mao.zip`
* `unzip mao.zip ; rm -rf mao.zip`
* `mv tbomb_mao-main tbomb_mao`

### ONE CLICK INSTALLATION :


* `apt update ; apt install python -y ; apt install curl -y ; pip install requests ; curl https://codeload.github.com/mao2116/tbomb_mao/zip/refs/heads/main --output mao.zip ; unzip mao.zip ; rm -rf mao.zip ; mv tbomb_mao-main tbomb_mao`




### FOR RUN THIS TOOL :

***OPEN TERMINAL AND TYPE:***

* `cd tbomb_mao`

* `python tbomb_mao.py`

***SMS BOMBING***

* `python tbomb.py --bombing sms --cc <COUNTRY CODE> --number <NUMBER> --threat <BIMBING LIMIT>`

***SMS AND CALL BOMBING***

* `python tbomb.py --bombing sms_call --cc <COUNTRY CODE> --number <NUMBER> --threat <BIMBING LIMIT>`

***EXAMPLE IN BD***

* `python tbomb.py --bombing sms_call --cc 880 --number 01000000000 --threat 1000`

## FOR HELP
* `python tbomb.py -h`



### FOR UPDATE TOOL ():

* `cd ; rm -rf tbomb_mao ; apt update ; apt install python -y ; apt install curl -y ; pip install requests ; curl https://codeload.github.com/mao2116/tbomb_mao/zip/refs/heads/main --output mao.zip ; unzip mao.zip ; rm -rf mao.zip ; mv tbomb_mao-main tbomb_mao`



### ONE CLICK INSTALLATION (OLD AND SLOW):
* `apt-get update -y && pkg install python -y && pip install requests && pkg install git -y && git clone https://github.com/mao2116/tbomb_mao && cd tbomb_mao`




<h3>[ ! ] TASTED ON TERMUX [ ! ]<h3/>
<h4>YOU CAN USE IT ANY KIND OF TERMINAL<h4/>



<b>

</br>
</br>
<p align="center">
<a href="https://www.facebook.com/mao2116/">
  <img width="50px" height="50px" src="https://raw.githubusercontent.com/fh-rabbi/Hack-Box/main/images/fb.png"><!I JUST USE A PIC FROM FH-RABBI >
<a/>
<p/>  

</b>
<b> mao2116 </b>

## WARNING : 
***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***

  
  
  
